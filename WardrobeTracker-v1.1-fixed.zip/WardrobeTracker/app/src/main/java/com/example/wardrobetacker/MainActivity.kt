package com.example.wardrobetacker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

 data class ClothingItem(
    val id: Int,
    val name: String,
    val category: String,
    val color: String,
    val brand: String = "",
    val price: String = "",
    val worn: Int = 0
)

class WardrobeViewModel : ViewModel() {
    var items by mutableStateOf(
        listOf(
            ClothingItem(1, "Black T-Shirt", "T-Shirt", "Black", "Nike", "1299", 5),
            ClothingItem(2, "White Shirt", "Shirt", "White", "Van Heusen", "1899", 2),
            ClothingItem(3, "Blue Jeans", "Jeans", "Blue", "Levi's", "2999", 8),
            ClothingItem(4, "Beige Chinos", "Pants", "Beige", "", "1599", 3)
        )
    )
        private set

    private var nextId = 5

    fun add(name: String, category: String, color: String, brand: String, price: String) {
        items = items + ClothingItem(nextId++, name, category, color, brand, price, 0)
    }

    fun wear(id: Int) {
        items = items.map { if (it.id == id) it.copy(worn = it.worn + 1) else it }
    }

    fun remove(id: Int) {
        items = items.filterNot { it.id == id }
    }
}

@Composable
fun App(vm: WardrobeViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                listOf("Wardrobe", "Outfits", "Stats").forEachIndexed { i, label ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text(if (i == 0) "👕" else if (i == 1) "👔" else "📊") },
                        label = { Text(label) }
                    )
                }
            }
        },
        floatingActionButton = {
            if (tab == 0) FloatingActionButton(onClick = { showAdd = true }) { Text("+") }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                0 -> Wardrobe(vm)
                1 -> Outfits(vm)
                2 -> Stats(vm)
            }
        }
    }

    if (showAdd) AddDialog(vm) { showAdd = false }
}

@Composable
fun Wardrobe(vm: WardrobeViewModel) {
    Column(Modifier.padding(16.dp)) {
        Text("My Wardrobe", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("${vm.items.size} items", color = Color.Gray)
        Spacer(Modifier.height(16.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(vm.items) { item ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Box(
                            Modifier.fillMaxWidth().height(110.dp).background(
                                colorFor(item.color), RoundedCornerShape(12.dp)
                            ),
                            contentAlignment = Alignment.Center
                        ) { Text("👕", style = MaterialTheme.typography.displaySmall) }
                        Spacer(Modifier.height(8.dp))
                        Text(item.name, fontWeight = FontWeight.SemiBold)
                        Text("${item.category} • ${item.color}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        Text("Worn ${item.worn} times", style = MaterialTheme.typography.bodySmall)
                        Button(
                            onClick = { vm.wear(item.id) },
                            modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                        ) { Text("Mark worn") }
                    }
                }
            }
        }
    }
}

@Composable
fun Outfits(vm: WardrobeViewModel) {
    Column(Modifier.padding(16.dp)) {
        Text("Outfit Builder", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("Pick pieces from your wardrobe to create outfits.")
        Spacer(Modifier.height(20.dp))
        vm.items.groupBy { it.category }.forEach { (cat, clothing) ->
            Text(cat, fontWeight = FontWeight.Bold)
            clothing.forEach { item ->
                Text("• ${item.name} (${item.color})", Modifier.padding(6.dp))
            }
        }
    }
}

@Composable
fun Stats(vm: WardrobeViewModel) {
    val total = vm.items.sumOf { it.worn }
    Column(Modifier.padding(16.dp)) {
        Text("Wardrobe Stats", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        Stat("Total items", vm.items.size.toString())
        Stat("Total wears", total.toString())
        Stat("Most worn", vm.items.maxByOrNull { it.worn }?.name ?: "—")
    }
}

@Composable
fun Stat(a: String, b: String) {
    Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Row(
            Modifier.padding(18.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(a)
            Text(b, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun AddDialog(vm: WardrobeViewModel, onClose: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("T-Shirt") }
    var color by remember { mutableStateOf("Black") }
    var brand by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Add clothing") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Name") })
                OutlinedTextField(cat, { cat = it }, label = { Text("Category") })
                OutlinedTextField(color, { color = it }, label = { Text("Color") })
                OutlinedTextField(brand, { brand = it }, label = { Text("Brand") })
                OutlinedTextField(price, { price = it }, label = { Text("Price") })
            }
        },
        confirmButton = {
            Button(
                enabled = name.isNotBlank(),
                onClick = { vm.add(name, cat, color, brand, price); onClose() }
            ) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}

fun colorFor(c: String) = when (c.lowercase()) {
    "black" -> Color(0xFF303030)
    "white" -> Color(0xFFEDEDED)
    "blue" -> Color(0xFF90CAF9)
    "beige" -> Color(0xFFD7C4A3)
    else -> Color(0xFFD1C4E9)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContent { MaterialTheme { App(viewModel()) } }
    }
}
